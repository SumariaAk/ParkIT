// module.exports={
//     SENDGRID_API: "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",
// }
const SENDGRID_API = "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";
export default SENDGRID_API;