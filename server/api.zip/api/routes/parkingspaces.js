import express from 'express';

import * as parkingspacesController from '../controllers/parkingspaces.js';

const router = express.Router();
import multer from 'multer';

//store file in the public/images/ folder with new fileName containing timestamp
const storage = multer.diskStorage({
  destination: (request, file, cb) => {
    cb(null, './public/images/');
  },
  filename: (request, file, cb) => {
    cb(null, Date.now() + file.originalname);
  },
});

//check if valid file is sent
const upload = multer({
  storage: storage,
  fileFilter: (request, file, cb) => {
    if (
      file.mimetype == 'image/png' ||
      file.mimetype == 'image/jpg' ||
      file.mimetype == 'image/jpeg'
    ) {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
    }
  },
});

/**
 * Create route for API
 */
router.route('/parkingspaces').get(parkingspacesController.index);
//  .post(parkingspacesController.save);

router.post(
  '/parkingspaces',
  upload.single('parking_img'),
  parkingspacesController.save
);

router
  .route('/parkingspaces/:id')
  .get(parkingspacesController.get)
  .put(parkingspacesController.update)
  .delete(parkingspacesController.remove);

export default router;
