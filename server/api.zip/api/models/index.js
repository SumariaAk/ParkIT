import User from "./user.js";
import parkingspace from "./parkingspaces.js";

export default { User, parkingspace};
