import Mongoose from "mongoose";
  
const parkingspaceSchema = new Mongoose.Schema({
    _id: String,
    name: String
})
  
const useridSchema = new Mongoose.Schema({
    _id: String,
    userid: String,
    first_name: String,
    last_name : String
})
  
const ParkingSpace = new Mongoose.model('parkingspace', parkingspaceSchema);
const User = new Mongoose.model('customer', User);
  
module.exports = { Order, Customer };